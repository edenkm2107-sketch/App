# Objectif 18 — source Android

## Gratuit
Android Studio, Kotlin, WebView, planning local, notes, calcul de moyenne, thèmes et notifications locales sont gratuits. Ce projet n'utilise pas de serveur payant.

## IA
Le bouton IA doit ouvrir ChatGPT dans le navigateur avec une consigne préremplie. Cela nécessite Internet et peut demander une connexion. Une IA conversationnelle intégrée par API peut coûter de l'argent ; aucune clé API n'est incluse ici.

## Construire l'APK
1. Installe Android Studio depuis le site officiel Android Developers.
2. Décompresse `objectif18-android-source.zip`.
3. Dans Android Studio, ouvre le dossier `objectif18-android`.
4. Accepte la synchronisation Gradle et installe le SDK Android API 35 si demandé.
5. Choisis **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Quand la compilation est terminée, clique sur **locate** pour trouver `app-debug.apk`.
7. Transfère le fichier sur ton Android, ouvre-le et autorise si nécessaire l'installation depuis cette source.
8. Autorise les notifications dans Android et configure un rappel dans l'application.

## À savoir
Ceci est le projet source, pas un APK déjà compilé. Je n'ai pas pu compiler ni tester l'APK dans cet environnement. Les alarmes Android peuvent être retardées par les réglages d'économie de batterie. Teste la fréquence des rappels sur ton appareil. Ne stocke pas de mot de passe Pronote dans l'application.

## Google Drive : partager le fichier APK
Google Drive peut héberger le fichier `app-debug.apk`, mais ne transforme pas le projet en application à lui seul.
1. Après compilation, trouve `app-debug.apk` sur l'ordinateur.
2. Envoie ce fichier dans Google Drive.
3. Sur le téléphone, ouvre Drive et télécharge le fichier APK.
4. Ouvre le fichier téléchargé, puis autorise l'installation depuis cette source si Android le demande.
5. Une fois installé, Objectif 18 apparaît dans la liste des applications avec son icône.
Pour une diffusion publique via Google Play, il faut suivre les règles du Play Store ; Drive sert seulement à partager le fichier d'installation.

## Écran d'humeur
Un écran demande l'humeur à chaque ouverture de l'application et propose une suggestion douce de révision. Le choix est conservé localement sur l'appareil.

## Alternative web installable
Un dossier `objectif18-web` est aussi fourni séparément sous forme ZIP. Pour que Chrome propose une installation PWA et que le cache hors ligne fonctionne, il faut héberger les fichiers sur un site HTTPS ; ouvrir un simple fichier local ne suffit généralement pas.


## Compilation de l'APK en ligne depuis un téléphone

Ce projet contient aussi un workflow GitHub Actions (`.github/workflows/build-apk.yml`).
Après avoir créé un dépôt GitHub et envoyé le contenu du dossier `objectif18-android` dans ce dépôt :
1. Ouvrir l'onglet **Actions** du dépôt.
2. Choisir **Construire APK Objectif 18**.
3. Appuyer sur **Run workflow**.
4. Quand l'exécution est terminée, ouvrir l'exécution réussie et récupérer l'artefact **Objectif-18-APK-debug**.
5. Décompresser l'artefact pour obtenir `app-debug.apk`.

Important : le workflow n'a pas été exécuté ni testé ici. L'APK n'est donc pas encore généré. Ne partage jamais de mot de passe ou de jeton GitHub dans une conversation.
