package fr.objectif18.app

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver as Receiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import java.util.Calendar

object ReminderScheduler {
    private fun pi(c: Context) = PendingIntent.getBroadcast(c,180,Intent(c,ReminderReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun cancel(c: Context) { (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c)) }
    fun schedule(c: Context,time: String,frequency: String) {
        val bits=time.split(":"); val h=bits.getOrNull(0)?.toIntOrNull()?:17; val m=bits.getOrNull(1)?.toIntOrNull()?:0
        val cal=Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY,h);set(Calendar.MINUTE,m);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)
            if(timeInMillis<=System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1)
            if(frequency=="Du lundi au vendredi") while(get(Calendar.DAY_OF_WEEK)==Calendar.SATURDAY || get(Calendar.DAY_OF_WEEK)==Calendar.SUNDAY) add(Calendar.DAY_OF_YEAR,1)
            if(frequency=="Le week-end") while(get(Calendar.DAY_OF_WEEK)!=Calendar.SATURDAY && get(Calendar.DAY_OF_WEEK)!=Calendar.SUNDAY) add(Calendar.DAY_OF_YEAR,1)
        }
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setInexactRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pi(c))
    }
}
class ReminderReceiver: Receiver() {
    override fun onReceive(c: Context, i: Intent?) {
        val p=c.getSharedPreferences("objectif18",Context.MODE_PRIVATE); if(!p.getBoolean("enabled",true)) return
        val nm=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager; val id="objectif18"
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(id,"Rappels de révision",NotificationManager.IMPORTANCE_DEFAULT))
        if(Build.VERSION.SDK_INT<33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED) {
            val b=if(Build.VERSION.SDK_INT>=26) Notification.Builder(c,id) else Notification.Builder(c)
            nm.notify(180,b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Objectif 18 📚").setContentText("C'est le moment de réviser !").setAutoCancel(true).build())
        }
        ReminderScheduler.schedule(c,p.getString("time","17:00")?:"17:00",p.getString("frequency","Tous les jours")?:"Tous les jours")
    }
}
class BootReceiver: Receiver() {
    override fun onReceive(c: Context,i: Intent?) {
        val p=c.getSharedPreferences("objectif18",Context.MODE_PRIVATE)
        if(p.getBoolean("enabled",false)) ReminderScheduler.schedule(c,p.getString("time","17:00")?:"17:00",p.getString("frequency","Tous les jours")?:"Tous les jours")
    }
}
