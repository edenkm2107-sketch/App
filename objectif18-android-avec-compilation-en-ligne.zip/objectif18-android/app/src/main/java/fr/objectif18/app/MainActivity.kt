package fr.objectif18.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 44)
        }
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(AppBridge(this), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
}

class AppBridge(private val ctx: Context) {
    @JavascriptInterface fun setReminder(time: String, frequency: String, enabled: Boolean) {
        val p = ctx.getSharedPreferences("objectif18", Context.MODE_PRIVATE)
        p.edit().putString("time",time).putString("frequency",frequency).putBoolean("enabled",enabled).apply()
        if (enabled) ReminderScheduler.schedule(ctx,time,frequency) else ReminderScheduler.cancel(ctx)
        (ctx as? Activity)?.runOnUiThread { Toast.makeText(ctx, if(enabled) "Rappel programmé" else "Rappels désactivés", Toast.LENGTH_SHORT).show() }
    }
    @JavascriptInterface fun openCoach(prompt: String) {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://chatgpt.com/?q="+Uri.encode(prompt))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
